"use client"

import { useState } from "react"
import { PivotTable } from "@/components/pivot-table"
import type { ColumnDefinition, RowGrouping } from "@/components/pivot-table"

// Sample data
const SAMPLE_DATA = [
  {
    asv: "ASV-001",
    repo: "Repository A",
    "use-case": "Data Analysis",
    services: "Data Processing",
    attributes: "High Performance",
    value: 2500,
    usage: 75,
    score: 4.2,
  },
  {
    asv: "ASV-001",
    repo: "Repository A",
    "use-case": "Data Analysis",
    services: "Visualization",
    attributes: "Interactive",
    value: 1800,
    usage: 60,
    score: 3.9,
  },
  {
    asv: "ASV-001",
    repo: "Repository B",
    "use-case": "API Gateway",
    services: "Authentication",
    attributes: "Secure",
    value: 3200,
    usage: 90,
    score: 4.7,
  },
  {
    asv: "ASV-002",
    repo: "Repository B",
    "use-case": "API Gateway",
    services: "Rate Limiting",
    attributes: "Scalable",
    value: 2900,
    usage: 85,
    score: 4.5,
  },
  {
    asv: "ASV-002",
    repo: "Repository C",
    "use-case": "Infrastructure",
    services: "Monitoring",
    attributes: "Real-time",
    value: 2100,
    usage: 70,
    score: 4.0,
  },
  {
    asv: "ASV-003",
    repo: "Repository C",
    "use-case": "Infrastructure",
    services: "Alerting",
    attributes: "Configurable",
    value: 1950,
    usage: 65,
    score: 3.8,
  },
  {
    asv: "ASV-003",
    repo: "Repository D",
    "use-case": "Web Services",
    services: "Content Delivery",
    attributes: "Fast",
    value: 2750,
    usage: 80,
    score: 4.3,
  },
  {
    asv: "ASV-004",
    repo: "Repository D",
    "use-case": "Web Services",
    services: "Backend",
    attributes: "Reliable",
    value: 3000,
    usage: 88,
    score: 4.6,
  },
  {
    asv: "ASV-004",
    repo: "Repository E",
    "use-case": "Data Storage",
    services: "Database",
    attributes: "Durable",
    value: 3300,
    usage: 92,
    score: 4.8,
  },
  {
    asv: "ASV-005",
    repo: "Repository E",
    "use-case": "Data Storage",
    services: "Caching",
    attributes: "Low Latency",
    value: 2600,
    usage: 78,
    score: 4.4,
  },
]

// Generate more sample data
for (let i = 6; i <= 20; i++) {
  const asvId = `ASV-${i.toString().padStart(3, "0")}`
  const repoIndex = i % 5
  const repoName = `Repository ${String.fromCharCode(65 + repoIndex)}`
  const useCases = ["Data Analysis", "API Gateway", "Infrastructure", "Web Services", "Data Storage"]
  const services = [
    "Data Processing",
    "Visualization",
    "Authentication",
    "Rate Limiting",
    "Monitoring",
    "Alerting",
    "Content Delivery",
    "Backend",
    "Database",
    "Caching",
  ]
  const attributes = [
    "High Performance",
    "Interactive",
    "Secure",
    "Scalable",
    "Real-time",
    "Configurable",
    "Fast",
    "Reliable",
    "Durable",
    "Low Latency",
  ]

  const useCase = useCases[i % 5]
  const service = services[i % 10]
  const attribute = attributes[i % 10]

  SAMPLE_DATA.push({
    asv: asvId,
    repo: repoName,
    "use-case": useCase,
    services: service,
    attributes: attribute,
    value: 1500 + Math.floor(Math.random() * 2000),
    usage: 50 + Math.floor(Math.random() * 50),
    score: 3.5 + Math.random(),
  })
}

export default function Home() {
  // Initial columns
  const [columns] = useState<ColumnDefinition[]>([
    { field: "value", title: "Value", format: "currency" },
    { field: "usage", title: "Usage (%)", format: "decimal" },
    { field: "score", title: "Score", format: "decimal" },
  ])

  // Initial row grouping
  const [rowGrouping] = useState<RowGrouping[]>([
    { field: "asv", direction: "asc" },
    { field: "repo", direction: "asc" },
  ])

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">Hierarchical Pivot Table</h1>

      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-2">Overview</h2>
        <p className="mb-4">
          This pivot table demonstrates advanced filtering and hierarchical data visualization. It allows exploring data
          across multiple levels: ASV → Repository → Use Case → Services → Attributes.
        </p>

        <h3 className="text-md font-medium mb-2">Key Features:</h3>
        <ul className="list-disc pl-6 mb-4">
          <li>Multi-level hierarchical filtering</li>
          <li>Column grouping and pivoting</li>
          <li>Sorting and aggregation functions (sum, average, count, min, max)</li>
          <li>Responsive design for all screen sizes</li>
          <li>Fully accessible with keyboard navigation and screen reader support</li>
        </ul>
      </div>

      <div className="pivot-table-wrapper">
        <PivotTable data={SAMPLE_DATA} initialColumns={columns} initialGrouping={rowGrouping} />
      </div>
    </div>
  )
}

